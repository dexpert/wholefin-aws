import crypto from 'crypto';

export const handler = async (event, context) => {

  const request = event.Records[0].cf.request;

  // Logic for hashing body (POST, PUT, PATCH)
  if (['POST', 'PUT', 'PATCH'].includes(request.method) && request.body && request.body.data) {
    const bodyData = request.body.encoding === 'base64'
      ? Buffer.from(request.body.data, 'base64')
      : request.body.data;

    const hash = crypto.createHash('sha256').update(bodyData).digest('hex');

    request.headers['x-amz-content-sha256'] = [{
      key: 'x-amz-content-sha256',
      value: hash
    }];
  } else {
    // Fallback for GET/DELETE or empty bodies
    const emptyHash = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
    request.headers['x-amz-content-sha256'] = [{
      key: 'x-amz-content-sha256',
      value: emptyHash
    }];
  }

  return request;
};
